module.exports = {
    client: 'mysql2',
    connection: {
        host: 'localhost',
        port: 3306,
        database: 'movies', 
        user: 'root',
        password: 'Mayabj123!'
    }
}